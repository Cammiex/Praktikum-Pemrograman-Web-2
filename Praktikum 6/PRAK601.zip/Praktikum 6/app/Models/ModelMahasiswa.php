<?php

namespace App\Models;

use CodeIgniter\Model;

class ModelMahasiswa extends Model
{
    protected $nama = "Aqil Rahmatullah";
    protected $nim = "2110817310012";
    protected $prodi = "Teknologi Informasi";
    protected $cita_cita = "Atlet";
    protected $hobi = "Futsal";
    protected $skill = "Bisa Main Rubik dengan satu tangan.";
    protected $quotes = "Jika tidak ada orang baik di dunia, maka jadilah salah satunya.";
    protected $foto = "Foto.jpg";

    public function getNama()
    {
        return $this->nama;
    }
    public function getNim()
    {
        return $this->nim;
    }
    public function getProdi()
    {
        return $this->prodi;
    }
    public function getcita_cita()
    {
        return $this->cita_cita;
    }
    public function gethobi()
    {
        return $this->hobi;
    }
    public function getSkill()
    {
        return $this->skill;
    }
    public function getQuotes()
    {
        return $this->quotes;
    }

    public function getFoto()
    {
        return $this->foto;
    }
}