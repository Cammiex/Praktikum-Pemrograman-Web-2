<!DOCTYPE html>
<html>

<head>
    <title>PRAK601</title>
    <style>
    * {
        box-sizing: border-box;
    }

    body {
        font-family: Arial, sans-serif;
        background-image: url(../images/bg.jpg);
        background-repeat: no-repeat;
        background-size: cover ;

        margin: 0;
        padding: 0;
    }

    .container {
        max-width: 600px;
        margin: 0 auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 10px;
        box-shadow: -6px 2px 20px 8px rgba(0, 0, 0, 0.1);
        margin-top: 100px;
    }

    h1 {
        color: #333;
        text-align: center;
        margin-bottom: 20px;
    }

    table {
        width: 100%;
    }

    th,
    td {
        padding: 10px;
        text-align: justify;
    }

    th {
        width: 30%;
    }

    .btn-container {
        display: flex;
        justify-content: center;
    }

    button {
        margin-top: 10px;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        background-color: salmon;
        color: #fff;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        cursor: pointer;
        transition: background-color 0.3s ease;
        position: relative;
        overflow: hidden;
    }

    button:hover {
        background-color: #ff7261;
    }
    </style>

</head>

<body>
    <div class="container">
        <h1>Beranda</h1>
        <table>
            <tr>
                <th>Nama</th>
                <td>
                    <?= $nama ?>
                </td>
            </tr>
            <tr>
                <th>NIM</th>
                <td>
                    <?= $nim ?>
                </td>
            </tr>
        </table>
        <div class="btn-container">
            <form action="/home/biodata">
                <button>
                    Biodata
                </button>
            </form>
        </div>
    </div>
</body>

</html>