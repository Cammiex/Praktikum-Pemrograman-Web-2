<?php

namespace App\Controllers;

use App\Models\ModelMahasiswa;

class Home extends BaseController
{
    public function index()
    {
        $mahasiswa = new ModelMahasiswa();
        return view('index', [
            "nama" => $mahasiswa->getNama(),
            "nim" => $mahasiswa->getNim(),
        ]);
    }
    public function biodata()
    {
        $mahasiswa = new ModelMahasiswa();
        return view('biodata', [
            "nama" => $mahasiswa->getNama(),
            "nim" => $mahasiswa->getNim(),
            "citacita" => $mahasiswa->getcita_cita(),
            "skill" => $mahasiswa->getSkill(),
            "prodi" => $mahasiswa->getProdi(),
            "quotes" => $mahasiswa->getQuotes(),
            "hobi" => $mahasiswa->gethobi(),
            "foto" => $mahasiswa->getFoto()
        ]);
    }
}